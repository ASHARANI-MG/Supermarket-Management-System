from tkinter import *
import os,index,datetime,sys
from PIL import Image, ImageTk
from tkinter import messagebox
import dele
def clse():
    root.destroy()
    os.system('python option.py')



def verifier():
    a=b=c=d=e=f=0
    if not product_name.get():
        #t1.insert(END,"<>product_name is required<>\n")
        a=1
    if not product_id.get():
        #t1.insert(END,"<>Adhar no is required<>\n")
        b=1
    if not manufacture_date.get():
        #t1.insert(END,"<>manufacture_date is required<>\n")
        c=1
    if not expiry_date.get():
        #t1.insert(END,"<>Phone number is requrired<>\n")
        d=1
    if not amount.get():
       #t1.insert(END,"<>Covid test result name is required<>\n")
        e=1
    if not units.get():
        #t1.insert(END,"<>Address is Required<>\n")
        f=1
    if a==1 or b==1 or c==1 or d==1 or e==1 or f==1:
        messagebox.showwarning("Warning","Fill the blank spaces.")
        return 1
    else:
        return 0


        

def ad():
    t1=datetime.datetime.now()
    m1=t1.strftime("%Y:%m:%d - %H:%M:%S")
    ls=product_name.get()+'|'+product_id.get()+'|'+manufacture_date.get()+'|'+expiry_date.get()+'|'+amount.get()+'|'+units.get()+'|'+m1+"\n"
    
    p=open('product.txt','a')
    p.write(ls)
    p.close()
                    


def add_product():
            ret=verifier()
            if ret==0:
                ad()
                messagebox.showwarning("Success","Added Successfully.")
                                 

def update_product():
    ret=verifier()
    if ret==0:
        dele.pos(product_id.get())
        
        ad()
        messagebox.showwarning("Success","Updated successfully")


        
if __name__=="__main__":
    root=Tk()
    root.minsize(935, 455)
    root.maxsize(935, 455)
    root.title("SUPERMARKET MANAGEMENT SYSTEM")
    
    root = Canvas(root,width = 935, height = 455)
    root.pack()
    image = PhotoImage(file="C:\\Users\\kavana\\OneDrive\\Desktop\\mint\\sprmrkt\\sprmrkt\\images\\green.png")
    root.create_image(0,0,anchor = NW, image = image)    


   
    label=Label(root,text="UPDATE DETAILS",font="bold",fg="Red")
    label.place(x=450,y=50)
    product_name=StringVar()
    product_id=StringVar()
    manufacture_date=StringVar()
    expiry_date=StringVar()
    amount=StringVar()
    units=StringVar()
    
    label1=Label(root,text="Product name:")
    label1.place(x=300,y=120)

    label2=Label(root,text="Product ID:")
    label2.place(x=300,y=170)

    label3=Label(root,text="manufacture_date:")
    label3.place(x=300,y=220)

    label4=Label(root,text="Expiry Date:")
    label4.place(x=300,y=270)

    label5=Label(root,text="Amount:")
    label5.place(x=300,y=320)

    label6=Label(root,text="Units:")
    label6.place(x=300,y=370)

    e1=Entry(root,textvariable=product_name,width=40)
    e1.place(x=420,y=120)

    e2=Entry(root,textvariable=product_id,width=40)
    e2.place(x=420,y=170)

    e3=Entry(root,textvariable=manufacture_date,width=40)
    e3.place(x=420,y=220)

    e4=Entry(root,textvariable=expiry_date,width=40)
    e4.place(x=420,y=270)
    
    e5=Entry(root,textvariable=amount,width=40)
    e5.place(x=420,y=320)

    e6=Entry(root,textvariable=units,width=40)
    e6.place(x=420,y=370)
   
    b4=Button(root,text="Submit",command=update_product,activebackground="pink",bg="#68BBE3",width=30)
    b4.place(x=363,y=420)
    b3=Button(root,text="Back",command=clse,bg="#68BBE3",activebackground="red",width=30)
    b3.place(x=700,y=420)
    root.mainloop()

