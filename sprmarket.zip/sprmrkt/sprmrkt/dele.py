from matplotlib import lines


def pos(s):
	a=open("product.txt")
	lines = a.readlines()
	a.close()
	p=-1
	q=0
	for i in lines:
		q=q+1
		p=i.find(s)
		if p!=-1:
			flag=i
			break
	if p!=-1:
		del lines[q-1]
		b=open("product.txt","w+")
		for line in lines:
			b.write(line)
		b.close()

def pos1(t):
	b=open("products.txt")
	lines = b.readlines()
	b.close()
	x=-1
	y=0
	for i in lines:
		y=y+1
		x=i.find(t)
		if x!=-1:
			del lines[y-1]
			c=open("products.txt","w+")
			for line in lines:
				c.write(line)
			c.close()

def pos2(q):
	d=open("sorted.txt")
	lines = d.readlines()
	d.close()
	r=-1
	s=0
	for i in lines:
		s=s+1
		r=i.find(q)
		if r!=-1:
			del lines[s-1]
			e=open("sorted.txt","w+")
			for line in lines:
				e.write(line)
			e.close()
	

		