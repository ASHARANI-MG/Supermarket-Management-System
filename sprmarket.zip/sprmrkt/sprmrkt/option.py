from tkinter import *
import os,index,datetime,sys
from PIL import Image, ImageTk
from tkinter import messagebox
def clse():
    root.destroy()
    os.system('python index.py')
def search():
    root.destroy()
    os.system('python search.py')
   
def add():
    root.destroy()
    os.system('python add.py')

def update():
    root.destroy()
    os.system('python update.py')

def delet():
    root.destroy()
    os.system('python delet.py')

def view():
    root.destroy()
    os.system('python view.py')
        
if __name__=="__main__":
    root=Tk()
    root.minsize(935, 455)
    root.maxsize(935, 455)
    root.title("SUPERMARKET MANAGEMENT SYSTEM")
   
    root = Canvas(root,width = 935, height = 455)
    root.pack()
    image = PhotoImage(file="C:\\Users\\kavana\\OneDrive\\Desktop\\mint\\sprmrkt\\sprmrkt\\images\\plain.png")
    root.create_image(0,0,anchor = NW, image = image)    



   
    b1=Button(root,text="ADD",command=add,activebackground="pink",bg="#68BBE3",width=30)
    b1.place(x=363,y=100)
    b1=Button(root,text="UPDATE",command=update,activebackground="pink",bg="#68BBE3",width=30)
    b1.place(x=363,y=150)
    b1=Button(root,text="DELETE",command=delet,activebackground="pink",bg="#68BBE3",width=30)
    b1.place(x=363,y=200)
    b1=Button(root,text="VIEW ALL",command=view,activebackground="pink",bg="#68BBE3",width=30)
    b1.place(x=363,y=250)
    b1=Button(root,text="SEARCH",command=search,activebackground="pink",bg="#68BBE3",width=30)
    b1.place(x=363,y=300)
    b1=Button(root,text="LOGOUT",command=clse,activebackground="pink",bg="#68BBE3",width=30)
    b1.place(x=363,y=350)
  
    
    root.mainloop()

