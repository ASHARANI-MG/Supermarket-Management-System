from tkinter import *
import os,index,datetime,sys
from PIL import Image, ImageTk
from tkinter import messagebox
def clse():
    sys.exit() 
def pos():
    ret=verifier()
    if ret==0:
        h=open("admin.txt")
        lines = h.readlines()
        h.close()
        for i in lines:
            if i.find(eid.get())!=-1 and i.find(psw.get())!=-1:
                messagebox.showwarning("success","Authorization Success.")
                root.destroy()
                rec()
                
                os.system('python option.py')
                break
        else:
            messagebox.showwarning("Warning","Embloyee id or password is incorrect.")
    else:
        messagebox.showwarning("Warning","Type Embloyee id and password.")
def verifier():
    a=b=0
    if not eid.get():
        a=1
    if not psw.get():
        b=1
    if a==1 or b==1 :
        return 1
    else:
        return 0  
        
def rec():
    o=datetime.datetime.now()
    k=o.strftime("%Y:%m:%d | %H:%M:%S")
    rc=eid.get()+" | "+k + "\n"
    g=open("record.txt",'a')
    g.write(rc)
    g.close()

                  




        
if __name__=="__main__":
    root=Tk()
    root.minsize(935, 455)
    root.maxsize(935, 455)
    root.title("SUPERMARKET MANAGEMENT SYSTEM")

    root = Canvas(root,width = 935, height = 455)
    root.pack()
    image = PhotoImage(file="C:\\Users\\kavana\\OneDrive\\Desktop\\mint\\sprmrkt\\sprmrkt\\images\\cart.png")
    root.create_image(0,0,anchor = NW, image = image)

    eid=StringVar()
    psw=StringVar()
    label=Label(root,text="LOGIN",font="bold",fg="Black",bg="orange")
    label.place(x=650,y=50)
    label1=Label(root,text="Admin id :",bg="white")
    label1.place(x=540,y=120)

    label2=Label(root,text="Password      :",bg="white")
    label2.place(x=540,y=150)


    e1=Entry(root,textvariable=eid)
    e1.place(x=670,y=120)

    e2=Entry(root,show='*',textvariable=psw)
    e2.place(x=670,y=150)
   
    b4=Button(root,text="Submit",command=pos,activebackground="pink",bg="orange",width=30)
    b4.place(x=520,y=200)
    b3=Button(root,text="Close",command=clse,bg="orange",activebackground="red",width=30)
    b3.place(x=520,y=240)
    root.mainloop()

