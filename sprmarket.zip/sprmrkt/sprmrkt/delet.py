from tkinter import *
import os,index,datetime,sys
from PIL import Image, ImageTk
from tkinter import messagebox
import dele
def clse():
    root.destroy()
    os.system('python option.py')



def delete_product():
    if not product_id.get():
        messagebox.showwarning("Warning","Fill the blank spaces.")
    else:
        dele.pos(product_id.get())
        dele.pos1(product_id.get())
        dele.pos2(product_id.get())
        messagebox.showwarning("Success","Deleted Successfully.")

        

                    





        
if __name__=="__main__":
    root=Tk()
    root.minsize(935, 455)
    root.maxsize(935, 455)
    root.title("SUPERMARKET MANAGEMENT SYSTEM")
    
    root = Canvas(root,width = 935, height = 455)
    root.pack()
    image = PhotoImage(file="C:\\Users\\kavana\\OneDrive\\Desktop\\mint\\sprmrkt\\sprmrkt\\images\\pink.png")
    root.create_image(0,0,anchor = NW, image = image)    


   
    label=Label(root,text="DELETE",font="bold",fg="Black")
    label.place(x=450,y=50)

    product_id=StringVar()


    label2=Label(root,text="Product ID:")
    label2.place(x=300,y=170)





    e2=Entry(root,textvariable=product_id,width=40)
    e2.place(x=420,y=170)

   
    b4=Button(root,text="Delete",command=delete_product,activebackground="red",bg="#68BBE3",width=30)
    b4.place(x=363,y=240)
    b3=Button(root,text="Back",command=clse,bg="#68BBE3",activebackground="red",width=30)
    b3.place(x=363,y=300)
    root.mainloop()

