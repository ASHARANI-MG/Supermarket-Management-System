output = open('buffered.txt','a')

with open('record.txt',buffering=2000) as f:
    for line in f:
        saveLine=line.replace('Admin | ','')
        output.write(saveLine)

output.close() 