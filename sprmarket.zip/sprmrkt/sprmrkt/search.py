from tkinter import *
import os,index,datetime,sys
from PIL import Image, ImageTk
from tkinter import messagebox
import dele
def clse():
    root.destroy()
    os.system('python option.py')

def ver():
    a=0
    if not product_name.get():
        messagebox.showwarning("Warning","Fill the blank spaces.")
        a=1
    return a


# def delete_product():
#     if not op.get():
#         messagebox.showwarning("Warning","Fill the blank spaces.")
#     else:
#         dele.pos(op.get())
        
#         messagebox.showwarning("Succes","Deleted Successfully.")

def ser():
    t=ver()
    if (t==0):
        f=open("product.txt")
        lines = f.readlines()
        f.close()
        for i in lines:
            if i.find(product_name.get())!=-1:
                t1.insert(END,"\n"+i+"\n")      

                    





        
if __name__=="__main__":
    root=Tk()
    root.minsize(935, 455)
    root.maxsize(935, 455)
    root.title("SUPERMARKET MANAGEMENT SYSTEM")
    
    
    root = Canvas(root,width = 935, height = 455)
    root.pack()
    image = PhotoImage(file="C:\\Users\\kavana\\OneDrive\\Desktop\\mint\\sprmrkt\\sprmrkt\\images\\lemon.png")
    root.create_image(0,0,anchor = NW, image = image)    


   
    label=Label(root,text="SEARCH",font="bold",fg="Red",bg="white")
    label.place(x=400,y=40)

    product_name=StringVar()


    label2=Label(root,text="Product Name:",bg="white")
    label2.place(x=250,y=120)





    e2=Entry(root,textvariable=product_name,width=40)
    e2.place(x=420,y=120)

   
    b4=Button(root,text="Search",command=ser,activebackground="red",bg="#68BBE3",width=30)
    b4.place(x=363,y=180)
    t1=Text(root,width=100,height=10,bg="white")
    t1.place(x=0,y=280)
    b3=Button(root,text="Back",command=clse,bg="#68BBE3",activebackground="red",width=30)
    b3.place(x=363,y=230)
    root.mainloop()

